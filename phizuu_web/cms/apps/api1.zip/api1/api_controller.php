<?php
require_once('../controller/json_controller.php');
require_once '../config/database.php';
include('../config/error_config.php');
include('../config/config.php');
include('../controller/db_connect.php');
include('../controller/helper.php');

include('../model/video_model.php');
include('../model/music_model.php');
include('../model/pic_model.php');
include('../model/news_model.php');
include('../model/tours_model.php');
include '../database/Dao.php';

$parts = explode('/', $_REQUEST['url']);

if ( isset($parts[1]) && $parts[1] != '') {
    $parts = explode('/', $_REQUEST['url']);
    $component = $parts[1];
    $app_id = $parts[0];
    if (isset($parts[2]))
        $phone = $parts[2];
    else
        $phone = 'iphone';
} else {
    $app_id = $parts[0];
    include('api_main_controller.php');
    exit;
}

$json_class= new jsonClass();

if($component == "music") {
    $json_video_stream = $json_class->streamMusic($app_id);
}
else if($component == "video") {
    $json_video_stream = $json_class->streamVideo($app_id,$phone);
}
else if($component == "images") {
    $json_video_stream = $json_class->streamImage($app_id);
}
else if($component == "news") {
    $json_video_stream = $json_class->streamNews($app_id);
}
else if($component == "tours") {
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        $postText = trim(file_get_contents('php://input'));
        $json = json_decode ($postText);
        $json_video_stream = $json_class->addRegisteration($json);
    } elseif ( $_SERVER['REQUEST_METHOD'] === 'GET' ) {
        $json_video_stream = $json_class->streamTours($app_id);
    }
}
else if($component == "links") {
    $json_video_stream = $json_class->streamMusic($app_id);
}
else if($component == "flyers") {
    $json_video_stream = $json_class->streamMusic($app_id);
}
else {
    $json_video_stream = $json_class->streamMusic($app_id);
}

echo $json_video_stream;

?>